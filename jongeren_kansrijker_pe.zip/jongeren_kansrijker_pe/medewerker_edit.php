<?php
session_start();
require_once 'db.php';
$db = new Database();

if (!isset($_SESSION['user_email']) || !isset($_COOKIE['user_id'])) {
    header("Location: login.php");
    exit;
}

if ($_GET['medewerker_id']) {
    $medewerker_id = $_GET['medewerker_id'];
    $medewerker = $db->getMedewerkerByID($medewerker_id);

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        try {
            $db->editMedewerker(
                $_POST['voornaam'],
                $_POST['achternaam'],
                $_POST['geboortedatum'],
                $_POST['telefoonnummer'],
                $_POST['email'],
                $medewerker_id
            );
            header("Location:medewerker_gegevens_confirm.php");
            exit;
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }

}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../jongeren_kansrijker_pe/css/reset.css">
    <link rel="stylesheet" href="../jongeren_kansrijker_pe/css/gegevens_medewerker.css">
    <title>Document</title>
</head>

<body>
    <header>
        <div class="logo">
            <img src="../jongeren_kansrijker_pe/images/logo.png" alt="logo">
        </div>
        <nav>
            <div class="main-title">
                <h1>Instituut Jongeren Kansrijker</h1>
            </div>
            <div class="login-btn">
                <a href="medewerkers_overzicht.php">Terug</a>
                <a href="uitloggen.php">Uitloggen</a>
            </div>
        </nav>
    </header>
    <main>
        <section>
            <div class="signin">
                <div class="content">
                    <h2>Mijn gegevens</h2>
                    <form class="form" method="POST">
                        <div class="inputBox">
                            <input type="text" name="voornaam" required value="<?php echo $medewerker['voornaam']; ?>"> <i>Voornaam</i>
                        </div>
                        <div class="inputBox">
                            <input type="text" name="achternaam" required value="<?php echo $medewerker['achternaam']; ?>"> <i>Achternaam</i>
                        </div>
                        <div class="inputBox">
                            <input type="date" name="geboortedatum" required value="<?php echo $medewerker['geboortedatum']; ?>"> <i>Geboortedatum</i>
                        </div>
                        <div class="inputBox">
                            <input type="number" name="telefoonnummer" required value="<?php echo $medewerker['telefoonnummer']; ?>"> <i>Telefoonnummer</i>
                        </div>
                        <div class="inputBox">
                            <input type="email" name="email" required value="<?php echo $medewerker['email']; ?>"> <i>Email</i>
                        </div>
                        <div class="inputBox">
                            <input type="submit" value="Wijzigen">
                        </div>
                    </form>
                </div>
            </div>
        </section>
    </main>
</body>

</html>
