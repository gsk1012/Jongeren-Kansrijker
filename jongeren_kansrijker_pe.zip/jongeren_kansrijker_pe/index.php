<?php
session_start();
require_once 'db.php';
$db = new Database();

$isUserLoggedIn = isset($_SESSION['user_email']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../jongeren_kansrijker_pe/css/reset.css">
    <link rel="stylesheet" href="../jongeren_kansrijker_pe/css/index.css">
    <title>Document</title>
</head>
<body>
<header>
        <div class="logo">
            <img src="../jongeren_kansrijker_pe/images/logo.png" alt="logo">
        </div>
        <nav>
            <div class="main-title">
                <h1>Instituut Jongeren Kansrijker</h1>
            </div>
            <div class="login-btn">
            <?php
                if ($isUserLoggedIn) {
                    include 'navbar.php';
                } else {
                    echo '<a href="login.php">Inloggen</a>';
                }
            ?>
            </div>
        </nav>
    </header>
    <main>
        <div class="bg-main"></div>
        <div class="overlay-text">
            <div class="text">
                <h2>Welkom op de homepage van Instituut Jongeren Kansrijker! Hier zetten we ons in voor de toekomst van jongeren in Almere
                    die een extra steuntje in de rug nodig hebben. Met trots hebben we al 25 jongeren begeleid op hun pad naar een betere toekomst.
                </h2><br>
            </div>
            <div class="text">
                <h2>Bij Instituut Jongeren Kansrijker geloven we dat elke jongere het potentieel heeft om een waardevolle bijdrage te leveren aan de maatschappij.
                     Ons doel is om deze jongeren te begeleiden, of ze nu meteen aan het werk gaan of een nieuwe opleiding volgen.
                </h2>
            </div>
        </div>
    </main>
</body>
</html>