<?php
require_once 'db.php';
$db = new Database();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../jongeren_kansrijker_pe/css/reset.css">
    <link rel="stylesheet" href="../jongeren_kansrijker_pe/css/overzicht.css">
    <title>Document</title>
</head>
<body>
    <header>
        <nav>
            <div class="login-btn">
                <a href="jongeren_overzicht.php">Jongeren</a>
                <a href="activiteiten_overzicht.php">Activiteiten</a>
                <div class="dropdown">
                    <img class="icon" src="../jongeren_kansrijker_pe/images/user-icon.jpg" alt="user-icon">
                    <div class="dropdown-item">
                        <ul>
                            <li><a class="icon-drop" href="gegevens_medewerker.php">Mijn gegevens</a></li>
                            <li><a class="icon-drop" href="medewerkers_overzicht.php">Overzicht medewerkers</a></li>
                            <li><a class="icon-drop" href="medewerker_toevoegen.php">Medewerker toevoegen</a></li>
                            <li><a class="icon-drop" href="uitloggen.php">Uitloggen</a></li>
                        </ul>
                    </div>
                    <div class="chevron-down"></div>
                </div>
            </div>
        </nav>
    </header>
    <main>
    </main>
</body>
</html>