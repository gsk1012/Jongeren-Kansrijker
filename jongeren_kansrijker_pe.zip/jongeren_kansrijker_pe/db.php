<?php

class Database
{
    private $host;
    private $username;
    private $password;
    private $database;
    private $dbh;

    public function __construct()
    {
        $this->host = 'localhost:3308';
        $this->username = 'root';
        $this->password = '';
        $this->database = 'jongeren_kansrijker';

        $dsn = "mysql:host=$this->host;dbname=$this->database";
        $this->dbh = new PDO($dsn, $this->username, $this->password);
    }

    public function validateUser($email, $wachtwoord)
    {
        $stmt = $this->dbh->prepare("SELECT * FROM medewerkers WHERE email = :email");
        $stmt->bindParam(':email', $email);
        $stmt->execute();
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($user !== false && password_verify($wachtwoord, $user['wachtwoord'])) {
            return true;
        } else {
            return false;
        }
    }

    public function overzichtJongeren() {
        $stmt = $this->dbh->query('SELECT * from jongeren');
        $rows = $stmt->fetchAll();
        return $rows;
    }

    public function GekoppeldeActiviteiten($jongereID) {
        $stmt = $this->dbh->prepare('SELECT ja.*, a.naam AS ochtend_activiteit_naam, b.naam AS middag_activiteit_naam
                                    FROM jongerenactiviteiten ja
                                    LEFT JOIN activiteiten a ON ja.ochtend_activiteit = a.activiteitID
                                    LEFT JOIN activiteiten b ON ja.middag_activiteit = b.activiteitID
                                    WHERE ja.jongereID = :jongereID');
        $stmt->bindParam(':jongereID', $jongereID);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function ActiviteitIDByName($naam) {
        $sql = 'SELECT activiteitID FROM activiteiten WHERE naam = :naam';
        $stmt = $this->dbh->prepare($sql);
        $stmt->bindParam(':naam', $naam);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        return $result ? $result['activiteitID'] : null;
    }

    public function editJongen(string $voornaam, string $achternaam, string $geboortedatum, int $telefoonnummer, $ochtendActiviteit, $middagActiviteit, int $jongereID) {
        $sqlUpdateJongen = 'UPDATE jongeren SET voornaam=:voornaam, achternaam=:achternaam, geboortedatum=:geboortedatum, telefoonnummer=:telefoonnummer WHERE jongereID=:jongereID';
        $stmtUpdateJongen = $this->dbh->prepare($sqlUpdateJongen);
        $stmtUpdateJongen->execute([
            'voornaam' => $voornaam,
            'achternaam' => $achternaam,
            'geboortedatum' => $geboortedatum,
            'telefoonnummer' => $telefoonnummer,
            'jongereID' => $jongereID
        ]);

        $sqlUpdateActiviteiten = 'UPDATE jongerenactiviteiten SET ochtend_activiteit = :ochtendActiviteit, middag_activiteit = :middagActiviteit WHERE jongereID = :jongereID';
        $stmtUpdateActiviteiten = $this->dbh->prepare($sqlUpdateActiviteiten);
        $stmtUpdateActiviteiten->execute([
            'ochtendActiviteit' => (!empty($ochtendActiviteit) ? $this->ActiviteitIDByName($ochtendActiviteit) : null),
            'middagActiviteit' => (!empty($middagActiviteit) ? $this->ActiviteitIDByName($middagActiviteit) : null),
            'jongereID' => $jongereID
        ]);
    }

    private function updateActiviteitForJongere(int $jongereID, $activiteitNaam, string $tijdstip) {
        if (!empty($activiteitNaam)) {
            $activiteitID = $this->ActiviteitIDByName($activiteitNaam);

            if (!empty($activiteitID)) {
                $activiteitColumn = (strpos($tijdstip, 'ochtend') !== false) ? 'ochtend_activiteit' : 'middag_activiteit';

                $sqlCheck = "SELECT * FROM jongerenactiviteiten WHERE jongereID = :jongereID";
                $stmtCheck = $this->dbh->prepare($sqlCheck);
                $stmtCheck->execute(['jongereID' => $jongereID]);

                if ($stmtCheck->rowCount() > 0) {
                    $sqlUpdate = "UPDATE jongerenactiviteiten SET $activiteitColumn = :activiteitID WHERE jongereID = :jongereID";
                    $stmtUpdate = $this->dbh->prepare($sqlUpdate);
                    $stmtUpdate->execute([
                        'jongereID' => $jongereID,
                        'activiteitID' => $activiteitID
                    ]);
                } else {
                    $sqlInsert = "INSERT INTO jongerenactiviteiten (jongereID, $activiteitColumn) VALUES (:jongereID, :activiteitID)";
                    $stmtInsert = $this->dbh->prepare($sqlInsert);
                    $stmtInsert->execute([
                        'jongereID' => $jongereID,
                        'activiteitID' => $activiteitID
                    ]);
                }
            }
        }
    }

    public function getActiviteitByID($activiteitID) {
        $stmt = $this->dbh->prepare('SELECT * FROM activiteiten WHERE activiteitID = :activiteitID');
        $stmt->bindParam(':activiteitID', $activiteitID);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function getJongereByID($jongereID) {
        $stmt = $this->dbh->prepare('SELECT * FROM jongeren WHERE jongereID = :jongereID');
        $stmt->bindParam(':jongereID', $jongereID);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function deleteJongen(int $jongereID) {
        $sqlDeleteActiviteiten = 'DELETE FROM jongerenactiviteiten WHERE jongereID = :jongereID';
        $stmtDeleteActiviteiten = $this->dbh->prepare($sqlDeleteActiviteiten);

        try {
            $stmtDeleteActiviteiten->execute(['jongereID' => $jongereID]);
        } catch (PDOException $e) {
            echo $e->getMessage();
            return;
        }

        $sqlDeleteJongere = 'DELETE FROM jongeren WHERE jongereID = :jongereID';
        $stmtDeleteJongere = $this->dbh->prepare($sqlDeleteJongere);

        try {
            $stmtDeleteJongere->execute(['jongereID' => $jongereID]);
        } catch (PDOException $e) {
            echo "Error deleting jongen: " . $e->getMessage();
        }
    }

    public function addJongen(string $voornaam, string $achternaam, string $geboortedatum, int $telefoonnummer, $ochtendActiviteit, $middagActiviteit) {
        $sql = 'INSERT INTO jongeren (voornaam, achternaam, geboortedatum, telefoonnummer) VALUES (:voornaam, :achternaam, :geboortedatum, :telefoonnummer)';
        $stmt = $this->dbh->prepare($sql);
        $stmt->execute([
            'voornaam' => $voornaam,
            'achternaam' => $achternaam,
            'geboortedatum' => $geboortedatum,
            'telefoonnummer' => $telefoonnummer,
        ]);

        $jongereID = $this->dbh->lastInsertId();

        $this->updateActiviteitForJongere($jongereID, $ochtendActiviteit, 'ochtend_activiteit');
        $this->updateActiviteitForJongere($jongereID, $middagActiviteit, 'middag_activiteit');
    }

    public function overzichtActiviteiten() {
        $stmt = $this->dbh->query('SELECT * from activiteiten');
        $rows = $stmt->fetchAll();
        return $rows;
    }

    public function editActiviteit(string $naam, string $locatie, string $beschrijving, int $activiteitID) {
        $sql = 'update activiteiten SET naam=:naam, locatie =:locatie, beschrijving =:beschrijving WHERE activiteitID=:activiteitID';
        $stmt = $this->dbh->prepare($sql);
        $stmt->execute([
            'naam' => $naam,
            'locatie' => $locatie,
            'beschrijving' => $beschrijving,
            'activiteitID' => $activiteitID
        ]);
    }

    public function deleteActiviteit(int $activiteitID) {
        $sql = 'DELETE FROM activiteiten WHERE activiteitID =:activiteitID';
        $stmt = $this->dbh->prepare($sql);
        $stmt->execute(['activiteitID' => $activiteitID]);
    }

    public function addActiviteit(string $naam, string $locatie, string $beschrijving) {
	    $sql = 'INSERT INTO activiteiten (naam, locatie, beschrijving) VALUES (:naam, :locatie, :beschrijving)';
	    $stmt = $this->dbh->prepare($sql);
	    $stmt->execute([
            'naam' => $naam,
            'locatie' => $locatie,
            'beschrijving' => $beschrijving
        ]);
    }

    public function getUserData($email) {
        $stmt = $this->dbh->prepare("SELECT * FROM medewerkers WHERE email = :email");
        $stmt->bindParam(':email', $email);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function updateMedewerker($voornaam, $achternaam, $geboortedatum, $telefoonnummer, $email, $newPassword, $medewerker_id) {
        $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

        $sql = 'UPDATE medewerkers SET voornaam=:voornaam, achternaam=:achternaam, geboortedatum=:geboortedatum, telefoonnummer=:telefoonnummer, email=:email, wachtwoord=:wachtwoord WHERE medewerker_id=:medewerker_id';
        $stmt = $this->dbh->prepare($sql);
        $stmt->execute([
            'voornaam' => $voornaam,
            'achternaam' => $achternaam,
            'geboortedatum' => $geboortedatum,
            'telefoonnummer' => $telefoonnummer,
            'email' => $email,
            'wachtwoord' => $hashedPassword,
            'medewerker_id' => $medewerker_id
        ]);
    }

    public function addMedewerker(string $voornaam, string $achternaam, string $geboortedatum, int $telefoonnummer, string $email, string $wachtwoord) {
        $hashedPassword = password_hash($wachtwoord, PASSWORD_DEFAULT);

        $sql = 'INSERT INTO medewerkers (voornaam, achternaam, geboortedatum, telefoonnummer, email, wachtwoord) VALUES (:voornaam, :achternaam, :geboortedatum, :telefoonnummer, :email, :wachtwoord)';
        $stmt = $this->dbh->prepare($sql);
        $stmt->execute([
            'voornaam' => $voornaam,
            'achternaam' => $achternaam,
            'geboortedatum' => $geboortedatum,
            'telefoonnummer' => $telefoonnummer,
            'email' => $email,
            'wachtwoord' => $hashedPassword
        ]);
    }

    public function overzichtMedewerkers() {
        $stmt = $this->dbh->query('SELECT * from medewerkers');
        $rows = $stmt->fetchAll();
        return $rows;
    }

    public function deleteMedewerker(int $medewerker_id) {
        $sql = 'DELETE FROM medewerkers WHERE medewerker_id =:medewerker_id';
        $stmt = $this->dbh->prepare($sql);
        $stmt->execute(['medewerker_id' => $medewerker_id]);
    }

    public function getMedewerkerByID($medewerker_id) {
        $stmt = $this->dbh->prepare('SELECT * FROM medewerkers WHERE medewerker_id = :medewerker_id');
        $stmt->bindParam(':medewerker_id', $medewerker_id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function editMedewerker(string $voornaam, string $achternaam, string $geboortedatum, int $telefoonnummer, string $email, int $medewerker_id) {
        $sqlUpdateMedewerker = 'UPDATE medewerkers SET voornaam=:voornaam, achternaam=:achternaam, geboortedatum=:geboortedatum, telefoonnummer=:telefoonnummer, email=:email WHERE medewerker_id=:medewerker_id';
        $stmtUpdateMedewerker = $this->dbh->prepare($sqlUpdateMedewerker);
        $stmtUpdateMedewerker->execute([
            'voornaam' => $voornaam,
            'achternaam' => $achternaam,
            'geboortedatum' => $geboortedatum,
            'telefoonnummer' => $telefoonnummer,
            'email' => $email,
            'medewerker_id' => $medewerker_id
        ]);
    }
}