<?php
session_start();
require_once 'db.php';
$db = new Database();

if (!isset($_SESSION['user_email']) || !isset($_COOKIE['user_id'])) {
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        $db->addActiviteit($_POST['naam'], $_POST['locatie'], $_POST['beschrijving']);
        header("Location:activiteit_edit_confirm.php");
        exit;
    }
    catch (Exception $e) {
        echo $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../jongeren_kansrijker_pe/css/reset.css">
    <link rel="stylesheet" href="../jongeren_kansrijker_pe/css/jongen_edit.css">
    <title>Document</title>
</head>
<body>
    <header>
        <div class="logo">
            <img src="../jongeren_kansrijker_pe/images/logo.png" alt="logo">
        </div>
        <nav>
            <div class="main-title">
                <h1>Instituut Jongeren Kansrijker</h1>
            </div>
            <div class="login-btn">
                <a href="jongeren_overzicht.php">Terug</a>
                <a href="uitloggen.php">Uitloggen</a>
            </div>
        </nav>
    </header>
    <main>
 <section>
   <div class="signin">
    <div class="content">
     <h2>Activiteit</h2>
     <form class="form" method="POST">
        <div class="inputBox">
            <input type="text" name="naam" required> <i>Activiteit</i>
        </div>
        <div class="inputBox">
            <input type="text" name="locatie" required> <i>Locatie</i>
        </div>
        <div class="inputBox">
            <textarea name="beschrijving" id="" cols="30" rows="5"></textarea><i>Beschrijving</i>
        </div>
        <div class="inputBox">
            <input type="submit" value="Toevoegen">
        </div>
     </form>
    </div>
   </div>
  </section>
    </main>
</body>
</html>