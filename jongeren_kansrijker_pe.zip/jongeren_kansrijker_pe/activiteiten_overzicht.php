<?php
session_start();
require_once 'db.php';
$db = new Database();

if (!isset($_SESSION['user_email']) || !isset($_COOKIE['user_id'])) {
    header("Location: login.php");
    exit;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../jongeren_kansrijker_pe/css/reset.css">
    <link rel="stylesheet" href="../jongeren_kansrijker_pe/css/jongeren_overzicht.css">
    <title>Document</title>
</head>
<body>
    <header>
        <div class="logo">
            <img src="../jongeren_kansrijker_pe/images/logo.png" alt="logo">
        </div>
        <nav>
            <div class="main-title">
                <h1>Instituut Jongeren Kansrijker</h1>
            </div>
            <div class="login-btn">
                <a href="activiteiten_toevoegen.php">Activiteit Toevoegen</a>
                <a href="index.php">Terug</a>
                <a href="uitloggen.php">Uitloggen</a>
            </div>
        </nav>
    </header>
    <main>
    <h1>Overzicht Activiteiten</h1>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Activiteit naam</th>
                            <th>Locatie</th>
                            <th>Beschrijving</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                    $data = $db ->overzichtActiviteiten();
                    foreach ($data as $activiteit) {
                        echo "<tr>";
                        echo "<td>".$activiteit['activiteitID']."</td>";
                        echo "<td>".$activiteit['naam']."</td>";
                        echo "<td>".$activiteit['locatie']."</td>";
                        echo "<td>".$activiteit['beschrijving']."</td>";
                        echo "<td><a class='bewerken-btn' href='activiteit_edit.php?activiteitID=" . $activiteit['activiteitID'] . "'>Bewerken</a></td>";
                        echo "<td><a class='verwijderen-btn' href='deletev2.php?activiteitID=" . $activiteit['activiteitID'] . "'>Verwijderen</a></td>";
                        echo "</tr>";
                    }
                    ?>
                </table>
            </div>
    </main>
</body>
</html>