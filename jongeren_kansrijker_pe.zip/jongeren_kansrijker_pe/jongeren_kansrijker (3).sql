-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3308
-- Generation Time: Jan 17, 2024 at 04:41 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jongeren_kansrijker`
--

-- --------------------------------------------------------

--
-- Table structure for table `activiteiten`
--

CREATE TABLE `activiteiten` (
  `activiteitID` int(11) NOT NULL,
  `naam` varchar(255) NOT NULL,
  `locatie` varchar(255) NOT NULL,
  `beschrijving` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `activiteiten`
--

INSERT INTO `activiteiten` (`activiteitID`, `naam`, `locatie`, `beschrijving`) VALUES
(6, 'Voetbaltraining', 'Sportveld Z', 'Wekelijkse voetbaltraining voor jongeren'),
(7, 'Leesclub Bijeenkomst', 'Stadsbibliotheek', 'Maandelijkse leesclubbijeenkomst'),
(8, 'Tenniswedstrijd', 'Tennisbaan X', 'Competitieve tenniswedstrijd voor jongeren'),
(9, 'Hardloopgroep', 'Stadspark', 'Samen hardlopen in een groep'),
(10, 'Gamen', 'Jongerencentrum GameZone', 'Gezellige avond met verschillende games');

-- --------------------------------------------------------

--
-- Table structure for table `jongeren`
--

CREATE TABLE `jongeren` (
  `jongereID` int(11) NOT NULL,
  `voornaam` varchar(255) NOT NULL,
  `achternaam` varchar(255) NOT NULL,
  `geboortedatum` date NOT NULL,
  `telefoonnummer` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `jongeren`
--

INSERT INTO `jongeren` (`jongereID`, `voornaam`, `achternaam`, `geboortedatum`, `telefoonnummer`) VALUES
(1, 'Jongen1', 'Achternaam1', '2002-10-20', 2147483647),
(22, 'maroune', 'el Jaghnouni', '2001-11-09', 304222);

-- --------------------------------------------------------

--
-- Table structure for table `jongerenactiviteiten`
--

CREATE TABLE `jongerenactiviteiten` (
  `jongereID` int(11) NOT NULL,
  `ochtend_activiteit` int(11) DEFAULT NULL,
  `middag_activiteit` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `jongerenactiviteiten`
--

INSERT INTO `jongerenactiviteiten` (`jongereID`, `ochtend_activiteit`, `middag_activiteit`) VALUES
(1, 6, 10),
(22, 9, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `medewerkers`
--

CREATE TABLE `medewerkers` (
  `medewerker_id` int(11) NOT NULL,
  `voornaam` varchar(255) NOT NULL,
  `achternaam` varchar(255) NOT NULL,
  `geboortedatum` date NOT NULL,
  `telefoonnummer` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `wachtwoord` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `medewerkers`
--

INSERT INTO `medewerkers` (`medewerker_id`, `voornaam`, `achternaam`, `geboortedatum`, `telefoonnummer`, `email`, `wachtwoord`) VALUES
(1, 'test', 'test', '2004-12-10', 686488749, 'test@outlook.com', '$2y$10$gz1RJJyXC/58I/mhQYGF8eXC5LC2utX2tSgkdq1/ns4aIEijuYYv6'),
(7, 'marouane', 'eljaghnouni', '2004-12-02', 666, 'marouane@gmail.com', '$2y$10$gIQZpxQIj7tMJ4HcvkTHcOUZYnVfOj8k83lG2MGx9cKjXsu8KKVDW');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activiteiten`
--
ALTER TABLE `activiteiten`
  ADD PRIMARY KEY (`activiteitID`);

--
-- Indexes for table `jongeren`
--
ALTER TABLE `jongeren`
  ADD PRIMARY KEY (`jongereID`);

--
-- Indexes for table `jongerenactiviteiten`
--
ALTER TABLE `jongerenactiviteiten`
  ADD PRIMARY KEY (`jongereID`),
  ADD KEY `ochtend_activiteit` (`ochtend_activiteit`),
  ADD KEY `middag_activiteit` (`middag_activiteit`);

--
-- Indexes for table `medewerkers`
--
ALTER TABLE `medewerkers`
  ADD PRIMARY KEY (`medewerker_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activiteiten`
--
ALTER TABLE `activiteiten`
  MODIFY `activiteitID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `jongeren`
--
ALTER TABLE `jongeren`
  MODIFY `jongereID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `medewerkers`
--
ALTER TABLE `medewerkers`
  MODIFY `medewerker_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `jongerenactiviteiten`
--
ALTER TABLE `jongerenactiviteiten`
  ADD CONSTRAINT `jongerenactiviteiten_ibfk_1` FOREIGN KEY (`jongereID`) REFERENCES `jongeren` (`jongereID`),
  ADD CONSTRAINT `jongerenactiviteiten_ibfk_2` FOREIGN KEY (`ochtend_activiteit`) REFERENCES `activiteiten` (`activiteitID`),
  ADD CONSTRAINT `jongerenactiviteiten_ibfk_3` FOREIGN KEY (`middag_activiteit`) REFERENCES `activiteiten` (`activiteitID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
