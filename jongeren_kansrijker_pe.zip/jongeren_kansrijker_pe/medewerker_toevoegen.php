<?php
session_start();
require_once 'db.php';
$db = new Database();

if (!isset($_SESSION['user_email']) || !isset($_COOKIE['user_id'])) {
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        $voornaam = $_POST['voornaam'];
        $achternaam = $_POST['achternaam'];
        $geboortedatum = $_POST['geboortedatum'];
        $telefoonnummer = $_POST['telefoonnummer'];
        $email = $_POST['email'];
        $wachtwoord = $_POST['wachtwoord'];

        $db = new Database();

        $db->addMedewerker($voornaam, $achternaam, $geboortedatum, $telefoonnummer, $email, $wachtwoord);
        header("Location:medewerkers_overzicht.php");
        exit;
    }
    catch (Exception $e) {
        echo $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../jongeren_kansrijker_pe/css/reset.css">
    <link rel="stylesheet" href="../jongeren_kansrijker_pe/css/jongen_edit.css">
    <title>Document</title>
</head>
<body>
    <header>
        <div class="logo">
            <img src="../jongeren_kansrijker_pe/images/logo.png" alt="logo">
        </div>
        <nav>
            <div class="main-title">
                <h1>Instituut Jongeren Kansrijker</h1>
            </div>
            <div class="login-btn">
                <a href="index.php">Terug</a>
                <a href="uitloggen.php">Uitloggen</a>
            </div>
        </nav>
    </header>
    <main>
 <section>
   <div class="signin">
    <div class="content">
     <h2>Medewerker</h2>
     <form class="form" method="POST">
        <div class="inputBox">
            <input type="text" name="voornaam" required> <i>Voornaam</i>
        </div>
        <div class="inputBox">
            <input type="text" name="achternaam" required> <i>Achternaam</i>
        </div>
        <div class="inputBox">
            <input type="date" name="geboortedatum" max="2004-12-31" required> <i>Geboortedatum</i>
        </div>
        <div class="inputBox">
            <input type="number" name="telefoonnummer" required> <i>Telefoonnummer</i>
        </div>
        <div class="inputBox">
            <input type="email" name="email" required> <i>Email</i>
        </div>
        <div class="inputBox">
            <input type="password" name="wachtwoord" required> <i>Wachtwoord</i>
        </div>
        <div class="inputBox">
            <input type="submit" value="Toevoegen">
        </div>
     </form>
    </div>
   </div>
  </section>
    </main>
</body>
</html>