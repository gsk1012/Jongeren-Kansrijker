<?php
session_start();
require_once 'db.php';
$db = new Database();

if (!isset($_SESSION['user_email']) || !isset($_COOKIE['user_id'])) {
    header("Location: login.php");
    exit;
}
    $activiteiten = $db->overzichtActiviteiten();
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        try {
            $ochtendActiviteit = isset($_POST['ochtend_activiteit']) ? $_POST['ochtend_activiteit'] : null;
            $middagActiviteit = isset($_POST['middag_activiteit']) ? $_POST['middag_activiteit'] : null;

            if ($ochtendActiviteit !== $_POST['current_ochtend_activiteit'] || $middagActiviteit !== $_POST['current_middag_activiteit']) {
                $db->addJongen(
                    $voornaam = $_POST['voornaam'],
                    $achternaam = $_POST['achternaam'],
                    $geboortedatum = $_POST['geboortedatum'],
                    $telefoonnummer = $_POST['telefoonnummer'],
                    $ochtendActiviteit,
                    $middagActiviteit,
                    $jongereID
                );
                header("Location: jongen_edit_confirm.php");
                exit;
            } else {
                header("Location: jongen_edit_confirm.php");
                exit;
            }
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../jongeren_kansrijker_pe/css/reset.css">
    <link rel="stylesheet" href="../jongeren_kansrijker_pe/css/jongen_edit.css">
    <title>Document</title>
</head>
<body>
    <header>
        <div class="logo">
            <img src="../jongeren_kansrijker_pe/images/logo.png" alt="logo">
        </div>
        <nav>
            <div class="main-title">
                <h1>Instituut Jongeren Kansrijker</h1>
            </div>
            <div class="login-btn">
                <a href="jongeren_overzicht.php">Terug</a>
                <a href="uitloggen.php">Uitloggen</a>
            </div>
        </nav>
    </header>
    <main>
        <section>
            <div class="signin">
                <div class="content">
                <h2>Jongen toevoegen</h2>
                <form class="form" method="POST">
                    <div class="inputBox">
                        <input type="text" name="voornaam" required> <i>Voornaam</i>
                    </div>
                    <div class="inputBox">
                        <input type="text" name="achternaam" required> <i>Achternaam</i>
                    </div>
                    <div class="inputBox">
                        <input type="date" name="geboortedatum" max="2005-12-31" required> <i>Geboortedatum</i>
                    </div>
                    <div class="inputBox">
                        <input type="number" name="telefoonnummer" required> <i>Telefoonnummer</i>
                    </div>
                    <div class="inputBox">
                        <input type="hidden" name="current_ochtend_activiteit" value="<?php echo isset($currentlySelectedActivities['ochtend_activiteit']) ? htmlspecialchars($currentlySelectedActivities['ochtend_activiteit']) : ''; ?>">
                        <input type="hidden" name="current_middag_activiteit" value="<?php echo isset($currentlySelectedActivities['middag_activiteit']) ? htmlspecialchars($currentlySelectedActivities['middag_activiteit']) : ''; ?>">
                        <select name="ochtend_activiteit" id="ochtend_activiteit">
                            <option value="">Geen</option>
                            <?php
                            foreach ($activiteiten as $activiteit) {
                                $selected = ($currentlySelectedActivities['ochtend_activiteit'] == $activiteit['naam']) ? 'selected' : '';
                                echo "<option value=\"{$activiteit['naam']}\" $selected>{$activiteit['naam']}</option>";
                            }
                            ?>
                        </select>
                        <i>Ochtendactiviteit:</i>
                    </div>
                    <div class="inputBox">
                        <select name="middag_activiteit" id="middag_activiteit">
                            <option value="" <?php echo (empty($currentlySelectedActivities['middag_activiteit'])) ? 'selected' : ''; ?>>Geen</option>
                            <?php
                            foreach ($activiteiten as $activiteit) {
                                $selected = ($currentlySelectedActivities['middag_activiteit'] == $activiteit['naam']) ? 'selected' : '';
                                echo "<option value=\"{$activiteit['naam']}\" $selected>{$activiteit['naam']}</option>";
                            }
                            ?>
                        </select>
                        <i>Middagactiviteit:</i>
                    </div>
                    <div class="inputBox">
                        <input type="submit" value="Toevoegen">
                    </div>
                </form>
                </div>
            </div>
        </section>
    </main>
</body>
</html>