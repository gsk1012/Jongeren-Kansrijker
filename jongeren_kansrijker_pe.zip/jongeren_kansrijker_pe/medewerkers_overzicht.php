<?php
session_start();
require_once 'db.php';
$db = new Database();

if (!isset($_SESSION['user_email']) || !isset($_COOKIE['user_id'])) {
    header("Location: login.php");
    exit;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../jongeren_kansrijker_pe/css/reset.css">
    <link rel="stylesheet" href="../jongeren_kansrijker_pe/css/jongeren_overzicht.css">
    <title>Document</title>
</head>
<body>
    <header>
        <div class="logo">
            <img src="../jongeren_kansrijker_pe/images/logo.png" alt="logo">
        </div>
        <nav>
            <div class="main-title">
                <h1>Instituut Jongeren Kansrijker</h1>
            </div>
            <div class="login-btn">
                <a href="index.php">Terug</a>
                <a href="medewerker_toevoegen.php">Medewerker toevoegen</a>
                <a href="uitloggen.php">Uitloggen</a>
            </div>
        </nav>
    </header>
    <main>
    <h1>Overzicht Medewerkers</h1>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Voornaam</th>
                            <th>Achternaam</th>
                            <th>Geboortedatum</th>
                            <th>Telefoonnummer</th>
                            <th>Email</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                    $data = $db ->overzichtMedewerkers();
                    foreach ($data as $medewerker) {
                        echo "<tr>";
                        echo "<td>".$medewerker['medewerker_id']."</td>";
                        echo "<td>".$medewerker['voornaam']."</td>";
                        echo "<td>".$medewerker['achternaam']."</td>";
                        echo "<td>".$medewerker['geboortedatum']."</td>";
                        echo "<td>".$medewerker['telefoonnummer']."</td>";
                        echo "<td>".$medewerker['email']."</td>";
                        echo "<td><a class='bewerken-btn' href='medewerker_edit.php?medewerker_id=" . $medewerker['medewerker_id'] . "'>Bewerken</a></td>";
                        echo "<td><a class='verwijderen-btn' href='deletev3.php?medewerker_id=" . $medewerker['medewerker_id'] . "'>Verwijderen</a></td>";
                        echo "</tr>";
                    }
                    ?>
                </table>
            </div>
    </main>
</body>
</html>