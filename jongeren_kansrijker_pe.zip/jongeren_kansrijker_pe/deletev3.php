<?php
try {
    require_once 'db.php';
    $db = new Database();

    if ($_GET['medewerker_id']) {
        $db->deleteMedewerker($_GET['medewerker_id']);
    }

}  catch(Exception $e) {
        echo $e->getMessage();
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../jongeren_kansrijker_pe/css/reset.css">
    <link rel="stylesheet" href="../jongeren_kansrijker_pe/css/jongen_edit_confirm.css">
    <title>Document</title>
</head>
<body>
    <header>
        <div class="logo">
            <img src="../jongeren_kansrijker_pe/images/logo.png" alt="logo">
        </div>
        <nav>
            <div class="main-title">
                <h1>Instituut Jongeren Kansrijker</h1>
            </div>
            <div class="login-btn">
                <a href="medewerkers_overzicht.php">Terug</a>
                <a href="uitloggen.php">Uitloggen</a>
            </div>
        </nav>
    </header>
    <main>
        <div>
            <h1>Gegevens zijn verwijderd</h1>
            <a href="medewerkers_overzicht.php">Terug naar overzicht</a>
        </div>
    </main>
</body>
</html>