<?php
session_start();
require_once 'db.php';
$db = new Database();

if (!isset($_SESSION['user_email']) || !isset($_COOKIE['user_id'])) {
    header("Location: login.php");
    exit;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../jongeren_kansrijker_pe/css/reset.css">
    <link rel="stylesheet" href="../jongeren_kansrijker_pe/css/jongeren_overzicht.css">
    <title>Document</title>
</head>
<body>
    <header>
        <div class="logo">
            <img src="../jongeren_kansrijker_pe/images/logo.png" alt="logo">
        </div>
        <nav>
            <div class="main-title">
                <h1>Instituut Jongeren Kansrijker</h1>
            </div>
            <div class="login-btn">
                <a href="jongeren_toevoegen.php">Jongen Toevoegen</a>
                <a href="index.php">Terug</a>
                <a href="uitloggen.php">Uitloggen</a>
            </div>
        </nav>
    </header>
    <main>
    <h1>Overzicht Jongeren</h1>
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Voornaam</th>
                        <th>Achternaam</th>
                        <th>Geboortedatum</th>
                        <th>Telefoonnummer</th>
                        <th>Ochtendactiviteit</th>
                        <th>Middagactiviteit</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                    $data = $db->overzichtJongeren();
                    foreach ($data as $jongen) {
                        echo "<tr>";
                        echo "<td>" . $jongen['jongereID'] . "</td>";
                        echo "<td>" . $jongen['voornaam'] . "</td>";
                        echo "<td>" . $jongen['achternaam'] . "</td>";
                        echo "<td>" . $jongen['geboortedatum'] . "</td>";
                        echo "<td>" . $jongen['telefoonnummer'] . "</td>";

                        $gekoppeldeActiviteiten = $db->GekoppeldeActiviteiten($jongen['jongereID']);
                        echo "<td>";
                        echo isset($gekoppeldeActiviteiten[0]['ochtend_activiteit_naam']) ? $gekoppeldeActiviteiten[0]['ochtend_activiteit_naam'] : 'Geen ochtendactiviteit';
                        echo "</td>";

                        echo "<td>";
                        echo isset($gekoppeldeActiviteiten[0]['middag_activiteit_naam']) ? $gekoppeldeActiviteiten[0]['middag_activiteit_naam'] : 'Geen middagactiviteit';
                        echo "</td>";

                        echo "<td><a class='bewerken-btn' href='jongen_edit.php?jongereID=" . $jongen['jongereID'] . "'>Bewerken</a></td>";
                        echo "<td><a class='verwijderen-btn' href='delete.php?jongereID=" . $jongen['jongereID'] . "'>Verwijderen</a></td>";
                        echo "</tr>";
                    }
                ?>
                </tbody>
            </table>
        </div>
    </main>
</body>
</html>
