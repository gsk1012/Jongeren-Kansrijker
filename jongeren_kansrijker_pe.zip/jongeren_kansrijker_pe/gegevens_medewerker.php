<?php
session_start();
require_once 'db.php';
$db = new Database();

$isUserLoggedIn = isset($_SESSION['user_email']);
$userData = [];

if ($isUserLoggedIn) {
    $userEmail = $_SESSION['user_email'];
    $userData = $db->getUserData($userEmail);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $voornaam = $_POST['voornaam'];
        $achternaam = $_POST['achternaam'];
        $geboortedatum = $_POST['geboortedatum'];
        $telefoonnummer = $_POST['telefoonnummer'];
        $email = $_POST['email'];
        $newPassword = $_POST['password'];

        $db->updateMedewerker($voornaam, $achternaam, $geboortedatum, $telefoonnummer, $email, $newPassword, $userData['medewerker_id']);
        $userData = $db->getUserData($email);
        header("Location:medewerker_gegevens_confirm.php");
        exit;
    } catch (Exception $e) {
        echo $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../jongeren_kansrijker_pe/css/reset.css">
    <link rel="stylesheet" href="../jongeren_kansrijker_pe/css/gegevens_medewerker.css">
    <title>Document</title>
</head>
<body>
    <header>
        <div class="logo">
            <img src="../jongeren_kansrijker_pe/images/logo.png" alt="logo">
        </div>
        <nav>
            <div class="main-title">
                <h1>Instituut Jongeren Kansrijker</h1>
            </div>
            <div class="login-btn">
                <a href="index.php">Terug</a>
                <a href="uitloggen.php">Uitloggen</a>
            </div>
        </nav>
    </header>
    <main>
        <section>
            <div class="signin">
                <div class="content">
                    <h2>Mijn gegevens</h2>
                    <form class="form" method="POST">
                        <div class="inputBox">
                            <input type="text" name="voornaam" value="<?php echo $userData['voornaam']; ?>" required> <i>Voornaam</i>
                        </div>
                        <div class="inputBox">
                            <input type="text" name="achternaam" value="<?php echo $userData['achternaam']; ?>" required> <i>Achternaam</i>
                        </div>
                        <div class="inputBox">
                            <input type="date" name="geboortedatum" value="<?php echo $userData['geboortedatum']; ?>" required> <i>Geboortedatum</i>
                        </div>
                        <div class="inputBox">
                            <input type="number" name="telefoonnummer" value="<?php echo $userData['telefoonnummer']; ?>" required> <i>Telefoonnummer</i>
                        </div>
                        <div class="inputBox">
                            <input type="email" name="email" value="<?php echo $userData['email']; ?>" required> <i>Email</i>
                        </div>
                        <div class="inputBox">
                            <input type="password" name="password"> <i>Nieuwe wachtwoord</i>
                        </div>
                        <input type="hidden" name="medewerkerID" value="<?php echo isset($userData['medewerkerID']) ? $userData['medewerkerID'] : ''; ?>">
                        <div class="inputBox">
                            <input type="submit" value="Wijzigen">
                        </div>
                    </form>
                </div>
            </div>
        </section>
    </main>
</body>
</html>
